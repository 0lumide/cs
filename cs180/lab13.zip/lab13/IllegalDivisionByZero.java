public class IllegalDivisionByZero extends Exception {
    IllegalDivisionByZero(String mess) {
        super(mess);
    }
}

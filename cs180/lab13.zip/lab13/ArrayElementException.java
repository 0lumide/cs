public class ArrayElementException extends Exception{
    ArrayElementException(String mess) {
        super(mess);
    }
    
}

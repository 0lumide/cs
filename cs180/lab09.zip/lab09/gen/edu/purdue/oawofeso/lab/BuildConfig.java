/** Automatically generated file. DO NOT MODIFY */
package edu.purdue.oawofeso.lab;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
package edu.purdue.oawofeso.lab;

import android.view.View.*;
import android.view.View;
import java.util.*;
import android.os.*;
import android.widget.*;

public class Listener implements OnClickListener
{
    /**
     * Handle "call backs" when the user presses one of the on-screen buttons.
     */
    @Override
    public void onClick(View arg) {

        //Create a Button obect and assign it to arg using TYPE CASTING
        Button b = (Button)arg;

        // use getText() method in Button to fetch the text content of the button as a CharSequence
        CharSequence cs = b.getText();
        if (cs.equals("Reset")) {
           StartActivity.strings.clear();
           StartActivity.logView.setText("");
           StartActivity.logIt("Reset requested");
        }
        else if (cs.equals("Serial")) {
            StartActivity.logIt(String.format("Current date and time:  %s",Calendar.getInstance().getTime()));
        }
        else if (cs.equals("Time")) {
            StartActivity.logIt("Build Number is: " + Build.SERIAL);
        }
        // Figure out which button was pressed; take an action...
        //Compare the obtained text to print the appropriate response using StartActivity.logIt() method;

 // if Reset: clear screen using the following two commands - 
 //StartActivity.strings.clear();
 //StartActivity.logView.setText("");
 //then print: "Reset requested"

 // if Time   print: the present time using:
 //StartActivity.logit(String.format("Current date and time:  %s",Calendar.getInstance().getTime()));

 // if Serial print: serial number using Build.SERIAL using a similar command given above 
  
        
    }
}

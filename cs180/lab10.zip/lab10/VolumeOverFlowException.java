public class VolumeOverFlowException extends Exception {
    public VolumeOverFlowException (String message) {
        super(message);
    }
    public VolumeOverFlowException () {
        super();
    }
}
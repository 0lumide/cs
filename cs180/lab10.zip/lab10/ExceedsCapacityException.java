public class ExceedsCapacityException extends Exception {
    public ExceedsCapacityException (String message) {
        super(message);
    }
    public ExceedsCapacityException () {
        super();
    }
}
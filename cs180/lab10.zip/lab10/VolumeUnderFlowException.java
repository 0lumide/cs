public class VolumeUnderFlowException extends Exception {
    public VolumeUnderFlowException (String message) {
        super(message);
    }
    public VolumeUnderFlowException () {
        super();
    }
}